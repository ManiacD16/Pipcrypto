import React, { useEffect } from "react";
import { motion, useAnimation } from "framer-motion";

const AnimatedArc: React.FC<{
  percentage: number;
  color: string;
  label: string;
}> = ({ percentage, color, label }) => {
  const controls = useAnimation();

  useEffect(() => {
    controls.start({ strokeDashoffset: 100 - percentage });
  }, [controls, percentage]);

  return (
    <div className="flex flex-col items-center">
      <h3 className="font-semibold mb-4 text-white text-center">{label}</h3>
      <div className="relative w-40 h-20">
        <svg viewBox="0 0 100 50" className="w-full h-full">
          <motion.path
            d="M10,50 A40,40 0 0,1 90,50"
            fill="none"
            stroke={color}
            strokeWidth="10"
            strokeDasharray="100"
            strokeDashoffset="100"
            animate={controls}
            transition={{ duration: 1.5, ease: "easeOut" }}
          />
          <path
            d="M90,50 A40,40 0 0,0 10,50"
            fill="none"
            stroke="#ccc"
            strokeWidth="10"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center text-xl font-bold text-white">
          {percentage.toFixed(2)}%
        </div>
      </div>
      <div className="flex justify-between w-40 text-sm mt-2 text-gray-300">
        <span>0%</span>
        <span>100%</span>
      </div>
    </div>
  );
};

const QraSupplyBurnChart: React.FC = () => {
  return (
    <section className="w-full bg-[#0c0435] py-16 px-4">
      <div className="max-w-5xl mx-auto bg-[#18103a] rounded-2xl py-12 px-6 md:px-16">
        <motion.h2
          className="text-3xl md:text-5xl font-bold text-center mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-white">$QRA Circulating Supply vs </span>
          <span className="bg-gradient-to-r from-[#a974fe] to-[#e96368] bg-clip-text text-transparent">
            Burning Chart
          </span>
        </motion.h2>
        <motion.p
          className="text-gray-300 text-center max-w-3xl mx-auto text-sm md:text-base"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          In accordance with our buy-back policy for token burns, we'll allocate
          50% of our monthly revenue across all three modules to burn 75% of the
          $QRA tokens, reducing the circulating supply. You can track the live
          progress of these burns here.
        </motion.p>

        <div className="flex flex-col md:flex-row justify-center gap-12 mt-16">
          <AnimatedArc
            percentage={75}
            color="#b30000"
            label="Total will be burned"
          />
          <AnimatedArc
            percentage={25}
            color="#4CAF50"
            label="Total will be remain"
          />
        </div>
      </div>
    </section>
  );
};

export default QraSupplyBurnChart;
