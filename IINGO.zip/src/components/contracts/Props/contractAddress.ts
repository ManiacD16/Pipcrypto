export const contractAddress = "0xe8BB2278a1ec13Afed0456EcD81Ca4Ef613F0F92";
export default contractAddress;
